package oop;

public class Service implements Discountable {
    private String description;
    private double basePrice;
    public Service ( String description , double basePrice ) {
        this.description = description;
        this.basePrice = basePrice;
    }
    public void displayInfo () {
        System.out.println ( "Service: " + description );
        System.out.println ( "Base Price: " + basePrice );
    }

        @override
        public void displayDiscount () {
            double discounted = basePrice * 0.95;
            System.out.println ( description + " | Before: " + basePrice + " | After: " + discounted );
        }
}