package oop;

public class publicvoid {

}
