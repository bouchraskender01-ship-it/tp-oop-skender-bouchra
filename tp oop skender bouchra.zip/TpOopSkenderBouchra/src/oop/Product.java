package oop;

public abstract class Product implements Discountable {
    private String id;
    private String name;
    private double price;
    private int quantity;
    private String category;
    protected static int totalproducts = 0;
    public Product ( String id, String name, Double price, int quantity, String category ) {
        this.id = id;
        this.name =  name ;
        this.price = price ;
        this.quantity = quantity ;
        this.category = category;
        ++totalproducts;
    }
    
    public void displayInfo () {
        System.out.println ( "ID: " + id );
        System.out.println ( "Name: " + name );
        System.out.println ( "Price: " + price );
        System.out.println ( "Quantity: " + quantity );
        System.out.println ( "Category: " + category );
    }

//overloading
     public void displayInfo ( String currency ) {
         if (currency.equalsIgnoreCase ( "Euro" ) ) {
             System.out.println ( "price in Euro: " + (price * 0.0067) );
         }
     }

    
    public void displayInfo ( boolean detailed ) {
        if (detailed) displayInfo ();
            else System.out.println ( "Name: " + name + "| Price: " + price );
            }
        
    public boolean isAvailable () {
        return quantity > 0;
            }
    
    public static int getTotalProducts () {
        return totalproducts;
            }

//Abstract method
    public abstract void specificInfo ();

//Getters & Setters with validation
    public void setName ( String name ) {
        if ( name == null || name.isEmpty () )
            throw new
                IllegalArgumentException ( "Name cannot be empty" );
        this.name = name;
    }

    public void setPrice ( double price ) {
        if ( price < 0 )
            throw new
                IllegalArgumentException ( "price cannot be negative" );
        this.price = price;
    }

    public void setQuantity ( int quantity ) {
        if ( quantity < 0 )
            throw new
                IllegalArgumentException ( "Quantity cannot be negative " );
                this.quantity = quantity;
    }

    @override
    public void displayDiscount () {
        double discounted = price * 0.9;
        System.out.println ( name + "| After: " + discounted );
    }
}

