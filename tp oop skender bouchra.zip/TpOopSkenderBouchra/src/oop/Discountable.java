package oop;

public interface Discountable {
    void displayDiscount ();
}