package oop;

import java.util.ArrayList;
public class Main {
    public static void main ( String[] args ) {
   

Product p1 = new FoodProduct ( "f01", "Milk", 120, 10, "Food", "2025-03-15" );
Product p2 = new ElectronicProduct ( "E01", "Laptop", 150000, 5, "Electronics", 24 );
p1.displayInfo ();
System.out.println ("-------");
p2.displayInfo ();
System.out.println ("\nPolymorphism:");
ArrayList<Product> products = new ArrayList<>();
products.add(p1);
products.add(p2);

for (Product p: products) {
    p.specificInfo();
}
    System.out.println ("\nDiscounts:");
    ArrayList<Discountable> list = new ArrayList<>();
    list.add(p1);
    list.add(p2);
    list.add( new Service("Home Delivery", 3000) );

    for (Discountable d: list) {
        d.displayDiscount();
    }
    System.out.println("\nTotal product:" + Product.getTotalProducts() );
}
    }
