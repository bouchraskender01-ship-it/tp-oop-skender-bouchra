package oop;

public @interface override {

}
